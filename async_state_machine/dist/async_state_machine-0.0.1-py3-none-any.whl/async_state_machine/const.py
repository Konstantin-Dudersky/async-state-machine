from typing import Final

# по непонятным причинам, при 0 иногда не выходит из цикла
INFINITE_CORO_SLEEP: Final[float] = 0.001
