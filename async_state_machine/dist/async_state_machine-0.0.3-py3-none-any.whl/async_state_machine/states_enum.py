"""Перечисление состояний."""

from enum import StrEnum


class StatesEnum(StrEnum):
    """Перечисление состояний."""
