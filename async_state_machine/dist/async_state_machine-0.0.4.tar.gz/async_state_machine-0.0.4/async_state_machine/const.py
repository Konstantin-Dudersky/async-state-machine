"""Константы."""

from typing import Final

INFINITE_CORO_SLEEP: Final[float] = 0.001
